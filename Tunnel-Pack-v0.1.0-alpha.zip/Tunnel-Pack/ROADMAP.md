# Roadmap
1. Link-method scanner: safely probe supported direct/encapsulated paths without replacing existing routes.
2. Engine adapters: BackPack, Backhaul, Rathole, EasyTier, experimental Paqet, and verify the exact Hedioum project before integration.
3. Repeatable benchmarks: loss, RTT, jitter, throughput, CPU, and stability over time.
4. Weighted scorecard: DPI/blocking resistance 35%, stability 25%, security 20%, sufficient throughput 12%, leak prevention 8%; confirmed security/leak failures are hard gates.
5. Pairing and web panel: authenticated token enrollment, TLS, role-based access, audit logs.
6. Supervisor and failover: health thresholds, hysteresis, staged switch, rollback, and per-service route policy.
7. Leak checks: IPv4/IPv6/DNS and route validation, with fail-closed behavior where configured.

Automatic switching must not be enabled until a working fallback is validated and rollback has been tested. DPI resistance is an empirical estimate, never a guarantee.
