# Tunnel Pack
**Version:** 0.1.0-alpha  
**Author label:** ABC  
**Target:** Ubuntu 24.04 (amd64/arm64 if distro Go supports it)

Tunnel Pack is intended to become a tunnel testing, scoring, monitoring, and failover manager. This alpha is deliberately read-only with respect to network configuration.

## What works in this alpha
- Interactive Persian CLI menu.
- Read-only host/kernel/congestion-control status.
- Basic peer ICMP ping and TCP reachability checks (ports 22, 80, 443, 8443).
- Scan results appended to `/var/lib/tunnel-pack/scans.jsonl` when permissions allow.
- Tunnel-engine catalog and scoring rubric.

## Not implemented yet
- Actual GRE/UDP/VXLAN/IPIP path scanner.
- Installation/configuration of BackPack, Backhaul, Rathole, Paqet, Hedioum, or EasyTier.
- Web panel, continuous monitoring, score history UI, automatic failover/rollback, leak testing.
- Token pairing between Iran and foreign servers.

Do not treat the current alpha as a production tunnel installer. It will not change routes, firewall rules, kernel parameters, or reboot a server.

## Install on each Ubuntu server
Copy/extract this folder on the server, then run:

```bash
cd Tunnel-Pack
sudo bash install.sh
```

Then run:

```bash
sudo tunnel-pack
```

Or run a basic check against the other server:

```bash
sudo tunnel-pack scan <OTHER_SERVER_IP>
```

Run the same commands on both Iran and foreign servers. A failed ping does not necessarily mean the path is unusable; ICMP can be blocked. The TCP checks only test common ports, not whether a tunnel can use them.

## Development
```bash
go test ./...
go build ./cmd/tunnel-pack
```

## Security
This is an early development scaffold. Review scripts before running them on production servers and keep SSH access available. The installer installs Go and builds the program; it does not configure a firewall or install tunnel services.
