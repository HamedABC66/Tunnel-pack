#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then echo "Run as root: sudo ./install.sh"; exit 1; fi
if ! command -v apt-get >/dev/null 2>&1; then echo "This installer currently supports Ubuntu/Debian only."; exit 1; fi
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y golang-go iputils-ping ca-certificates
install -d -m 0755 /usr/local/src/tunnel-pack
cp -a "$SCRIPT_DIR/go.mod" "$SCRIPT_DIR/cmd" "$SCRIPT_DIR/internal" /usr/local/src/tunnel-pack/ 2>/dev/null || true
cd /usr/local/src/tunnel-pack
go build -trimpath -ldflags "-s -w" -o /usr/local/bin/tunnel-pack ./cmd/tunnel-pack
chmod 0755 /usr/local/bin/tunnel-pack
install -d -m 0750 /var/lib/tunnel-pack
printf '\nInstalled: '; /usr/local/bin/tunnel-pack version
printf '\nRun: tunnel-pack\n'
printf 'Note: this alpha version does not install tunnel engines or enable automatic failover.\n'
