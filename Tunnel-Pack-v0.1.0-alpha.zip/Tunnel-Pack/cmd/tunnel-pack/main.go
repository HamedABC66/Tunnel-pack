package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"net"
	"os"
	"os/exec"
	"runtime"
	"strings"
	"time"
)

const version = "0.1.0-alpha"
const dataDir = "/var/lib/tunnel-pack"
const resultsFile = dataDir + "/scans.jsonl"

type Probe struct {
	Port       int    `json:"port"`
	Open       bool   `json:"open"`
	DurationMS int64  `json:"duration_ms"`
	Error      string `json:"error,omitempty"`
}
type Scan struct {
	Time       string  `json:"time"`
	Peer       string  `json:"peer"`
	PingOK     bool    `json:"ping_ok"`
	PingOutput string  `json:"ping_output,omitempty"`
	TCP        []Probe `json:"tcp_probes"`
}

func main() {
	if len(os.Args) > 1 {
		switch os.Args[1] {
		case "version", "--version", "-v":
			fmt.Printf("Tunnel Pack %s\n", version)
		case "status":
			status()
		case "scan":
			if len(os.Args) < 3 {
				fmt.Println("Usage: tunnel-pack scan <peer-ip-or-host>")
				os.Exit(2)
			}
			scan(os.Args[2])
		case "engines":
			engines()
		case "scorecard":
			scorecard()
		case "help", "--help", "-h":
			help()
		default:
			fmt.Printf("Unknown command: %s\n\n", os.Args[1])
			help()
			os.Exit(2)
		}
		return
	}
	menu()
}
func menu() {
	r := bufio.NewReader(os.Stdin)
	for {
		fmt.Printf("\n\033[1;36m╔══════════════════════════════════════╗\n║          TUNNEL PACK  %s       ║\n║               by ABC                 ║\n╚══════════════════════════════════════╝\033[0m\n", version)
		fmt.Println("  1) وضعیت سرور")
		fmt.Println("  2) اسکن ارتباط با سرور مقابل")
		fmt.Println("  3) فهرست موتورهای تانل")
		fmt.Println("  4) معیارهای امتیازدهی")
		fmt.Println("  5) خروج")
		fmt.Print("انتخاب شما: ")
		v, _ := r.ReadString('\n')
		v = strings.TrimSpace(v)
		switch v {
		case "1":
			status()
		case "2":
			fmt.Print("IP یا دامنه سرور مقابل: ")
			peer, _ := r.ReadString('\n')
			scan(strings.TrimSpace(peer))
		case "3":
			engines()
		case "4":
			scorecard()
		case "5", "q", "quit":
			return
		default:
			fmt.Println("گزینه نامعتبر است.")
		}
		fmt.Print("\nبرای ادامه Enter بزنید...")
		_, _ = r.ReadString('\n')
	}
}
func status() {
	fmt.Printf("\nTunnel Pack %s\nOS: %s/%s\nHostname: ", version, runtime.GOOS, runtime.GOARCH)
	h, _ := os.Hostname()
	fmt.Println(h)
	for _, cmd := range [][]string{{"uname", "-r"}, {"uptime", "-p"}} {
		if b, err := exec.Command(cmd[0], cmd[1:]...).CombinedOutput(); err == nil {
			fmt.Printf("%s: %s", cmd[0], strings.TrimSpace(string(b))+"\n")
		}
	}
	if b, err := os.ReadFile("/proc/sys/net/ipv4/tcp_congestion_control"); err == nil {
		fmt.Printf("TCP congestion control: %s", strings.TrimSpace(string(b))+"\n")
	}
	fmt.Println("توجه: این نسخه فقط اطلاعات پایه را می‌خواند و تنظیمات سیستم را تغییر نمی‌دهد.")
}
func scan(peer string) {
	if peer == "" {
		fmt.Println("IP یا دامنه وارد نشده است.")
		return
	}
	if net.ParseIP(peer) == nil {
		if _, err := net.LookupHost(peer); err != nil {
			fmt.Printf("حل نام ناموفق: %v\n", err)
			return
		}
	}
	res := Scan{Time: time.Now().UTC().Format(time.RFC3339), Peer: peer}
	fmt.Printf("\nدر حال بررسی %s ...\n", peer)
	if _, err := exec.LookPath("ping"); err == nil {
		args := []string{"-c", "4", "-W", "2", peer}
		if runtime.GOOS == "linux" {
			args = []string{"-c", "4", "-W", "2", peer}
		}
		b, err := exec.Command("ping", args...).CombinedOutput()
		res.PingOutput = strings.TrimSpace(string(b))
		res.PingOK = err == nil
		if res.PingOK {
			fmt.Println("Ping: پاسخ دریافت شد")
		} else {
			fmt.Println("Ping: پاسخ نگرفتیم یا ICMP مسدود است")
		}
		fmt.Println(res.PingOutput)
	} else {
		fmt.Println("ابزار ping نصب نیست؛ تست رد شد.")
	}
	for _, port := range []int{22, 80, 443, 8443} {
		start := time.Now()
		c, err := net.DialTimeout("tcp", net.JoinHostPort(peer, fmt.Sprint(port)), 1500*time.Millisecond)
		p := Probe{Port: port, Open: err == nil, DurationMS: time.Since(start).Milliseconds()}
		if err == nil {
			c.Close()
			fmt.Printf("TCP/%d: reachable (%d ms)\n", port, p.DurationMS)
		} else {
			p.Error = err.Error()
			fmt.Printf("TCP/%d: no connection (%s)\n", port, err)
		}
		res.TCP = append(res.TCP, p)
	}
	if err := os.MkdirAll(dataDir, 0750); err == nil {
		if f, err := os.OpenFile(resultsFile, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0640); err == nil {
			enc := json.NewEncoder(f)
			_ = enc.Encode(res)
			_ = f.Close()
			fmt.Printf("نتیجه ذخیره شد: %s\n", resultsFile)
		}
	}
	fmt.Println("این فقط اسکن پایه ICMP/TCP است؛ هنوز تست واقعی GRE/UDP و موتورهای تانل در این نسخه پیاده‌سازی نشده‌اند.")
}
func engines() {
	fmt.Println("\nکاتالوگ موتورهای هدف (در این نسخه هنوز نصب‌کننده فعال ندارند):")
	for _, s := range []string{"BackPack — planned adapter", "Backhaul — planned adapter", "Rathole — planned adapter", "Paqet — experimental candidate", "Hedioum Pool Tunnel — repository/compatibility verification required", "EasyTier — optional overlay"} {
		fmt.Println(" • " + s)
	}
	fmt.Println("هیچ موتور یا سرویس شبکه‌ای در نسخه alpha به‌صورت خودکار نصب یا تغییر داده نمی‌شود.")
}
func scorecard() {
	fmt.Println("\nمعیارهای پیشنهادی امتیازدهی (وزن‌ها):")
	fmt.Println("  1. مقاومت در برابر شناسایی/مسدودشدن: 35%")
	fmt.Println("  2. پایداری و قطعی:                  25%")
	fmt.Println("  3. امنیت و رمزنگاری:                20%")
	fmt.Println("  4. سرعت کافی برای مصرف روزمره:      12%")
	fmt.Println("  5. جلوگیری از نشت IP/DNS:             8%")
	fmt.Println("شرط سخت: نشت تأییدشده یا ضعف امنیتی جدی با امتیاز سایر بخش‌ها جبران نمی‌شود.")
	fmt.Println("امتیاز مقاومت در برابر DPI فقط از آزمایش و سابقه قابل برآورد است؛ تضمین ناشناس‌ماندن وجود ندارد.")
}
func help() {
	fmt.Println("Tunnel Pack — early development build\nCommands:\n  tunnel-pack                 Open interactive menu\n  tunnel-pack status          Show read-only system status\n  tunnel-pack scan <peer>     Basic ping and TCP reachability checks\n  tunnel-pack engines         Show planned tunnel adapters\n  tunnel-pack scorecard       Show scoring weights\n  tunnel-pack version         Print version")
}
